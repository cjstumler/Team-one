﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TextGameFinal
{
    public partial class Pyramid : Form
    {
        //text
        string Q1text = "You are an American Archaeologist exploring the Great Pyramid of Giza in Egypt. Recently, a new chamber has been discovered in the tomb, and you and your crew are eager to plunder its secrets before anyone else can. You're running out of patience, so you begin to explore the entrance to the chamber while your team readies the equipment. You take a few steps forward into the darkness and the ground suddenly shifts beneath your feet..." + "\r\n" + "\r\n" + "You wake up in a strange room, dimly lit by a few ancient sconces. Your communicator is shattered on the hard stone. It probably wouldn't even work all the way down here, you think. Then again, you don't have any idea how far you've fallen. Luckily, you aren't injured too badly, and your locator isn't broken, though it has no information about this unexplored chamber. You'll have to fill it in as you try to find your way out of this place. It looks like the only way to go is forward." + "\r\n" + "\r\n" + "(You can see your map to the left. It will update automatically as you move to new areas and complete tasks. The command line is how you can interact with the world. Commands are all one to three words, and all in lowercase. You can hit the Enter key to submit your command. It looks like the only way to go from here is South, so try to enter the 'south', 's', or 'down' command. All directional commands function the same, so use whichever you prefer. You can move in the other 3 cardinal directions in the same way. To see a list of some accepted commands, type 'help'.)";
        string Q2text = "Hello!";
        string Q3text = "Hello!";
        string Q4text = "Hello!";
        string Q5text = "Hello!";
        string Q6text = "Hello!";
        string Q7text = "Hello!";
        string Q8text = "Hello!";
        string Q9text = "Hello!";
        string Q10text = "Hello!";
        string Q11text = "Hello!";
        string Q12text = "Hello!";
        string Q13text = "Hello!";
        string Q14text = "Hello!";
        string Q15text = "Hello!";

        //look
        string Q1look = "Upon further inspection, it is a standard room, made of large, simple blocks of sandstone. Overhead, you can see light seeping in from the surface through the hole you fell in. On the floor close to where you fell, you see a large *wooden plank*. It looks like it could support your weight.";
        string Q2look = "Look!";
        string Q3look = "Look!";
        string Q4look = "Look!";
        string Q5look = "Look!";
        string Q6look = "Look!";
        string Q7look = "Look!";
        string Q8look = "Look!";
        string Q9look = "Look!";
        string Q10look = "Look!";
        string Q11look = "Look!";
        string Q12look = "Look!";
        string Q13look = "Look!";
        string Q14look = "Look!";
        string Q15look = "Look!";

        //location tracker
        string location = "Exploration Exodus - Q1";

        //quadrant completion status
        bool Q1complete = false;
        bool Q2complete = false;
        bool Q3complete = false;
        bool Q4complete = false;
        bool Q5complete = false;
        bool Q6complete = false;
        bool Q7complete = false;
        bool Q8complete = false;
        bool Q9complete = false;
        bool Q10complete = false;
        bool Q11complete = false;
        bool Q12complete = false;
        bool Q13complete = false;
        bool Q14complete = false;
        bool Q15complete = false;

        //quadrant entrance status
        bool Q1entered = true;
        bool Q2entered = false;
        bool Q3entered = false;
        bool Q4entered = false;
        bool Q5entered = false;
        bool Q6entered = false;
        bool Q7entered = false;
        bool Q8entered = false;
        bool Q9entered = false;
        bool Q10entered = false;
        bool Q11entered = false;
        bool Q12entered = false;
        bool Q13entered = false;
        bool Q14entered = false;
        bool Q15entered = false;

        //item possesion status
        bool woodenPlank = false;
        bool goldenKey = false;
        bool rustySword = false;
        bool shiningGemstone = false;
        bool burningTorch = false;
        bool ancientBread = false;
        bool workersAxe = false;
        bool grapplingHook = false;

        //obstacle completion status
        bool bridge = false;
        bool door = false;
        bool mummy = false;
        bool statue = false;
        bool webs = false;
        bool osiris = false;
        bool wall = false;
        bool grapple = false;

        public Pyramid()
        {
            InitializeComponent();
        }

        private void Pyramid_Load(object sender, EventArgs e)
        {
            ActiveControl = tbCommandLine;
            tbMessageLog.Text = Q1text;
        }

        //movement method
        private void move(string direction, PictureBox p1, PictureBox p2, Image i1, Image i2, string loc)
        {
            p1.Image = i1;
            p2.Image = i2;
            tbCommandLine.Text = "";
            location = loc;
            tbLocation.Text = location;
            tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "You decide to go "
                        + direction + ". "
                        + "You are now in "
                        + location + ".");
        }

        //non-movement method
        private void notMove(string direction)
        {
            tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "You cannot go "
                        + direction
                        + " from here. Please choose another action.");
            tbCommandLine.Text = "";
        }

        //Error handler
        public void error()
        {
            tbMessageLog.AppendText("\r\n" + "\r\n" +
                "The entered command was not recognized. " +
                "Check to make sure a valid command was entered. " +
                "You can type 'help' for a list of suggested commands.");
            tbCommandLine.Text = "";
        }

        //reset method
        public void reset()
        {
            location = "Exploration Exodus - Q1";
            tbLocation.Text = location;
            tbMessageLog.Text = Q1text;
            pbQ1.Image = Properties.Resources.incompThere;
            pbQ2.Image = Properties.Resources.undisc;
            pbQ3.Image = Properties.Resources.undisc;
            pbQ4.Image = Properties.Resources.undisc;
            pbQ5.Image = Properties.Resources.undisc;
            pbQ6.Image = Properties.Resources.undisc;
            pbQ7.Image = Properties.Resources.undisc;
            pbQ8.Image = Properties.Resources.undisc;
            pbQ9.Image = Properties.Resources.undisc;
            pbQ10.Image = Properties.Resources.undisc;
            pbQ11.Image = Properties.Resources.undisc;
            pbQ12.Image = Properties.Resources.undisc;
            pbQ13.Image = Properties.Resources.undisc;
            pbQ14.Image = Properties.Resources.undisc;
            pbQ15.Image = Properties.Resources.undisc;
            pbBridge.Image = Properties.Resources.empty1;
            Q1complete = false;
            Q2complete = false;
            Q3complete = false;
            Q4complete = false;
            Q5complete = false;
            Q6complete = false;
            Q7complete = false;
            Q8complete = false;
            Q9complete = false;
            Q10complete = false;
            Q11complete = false;
            Q12complete = false;
            Q13complete = false;
            Q14complete = false;
            Q15complete = false;
            Q1entered = true;
            Q2entered = false;
            Q3entered = false;
            Q4entered = false;
            Q5entered = false;
            Q6entered = false;
            Q7entered = false;
            Q8entered = false;
            Q9entered = false;
            Q10entered = false;
            Q11entered = false;
            Q12entered = false;
            Q13entered = false;
            Q14entered = false;
            Q15entered = false;
            woodenPlank = false;
            goldenKey = false;
            rustySword = false;
            shiningGemstone = false;
            burningTorch = false;
            ancientBread = false;
            workersAxe = false;
            grapplingHook = false;
            bridge = false;
            door = false;
            mummy = false;
            statue = false;
            webs = false;
            osiris = false;
            wall = false;
            grapple = false;
            tbCommandLine.Text = "";
        }

        //look method
        public void look(string look)
        {
            tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + look);
            tbCommandLine.Text = "";
        }

        //completion sequence
        public void gameComplete()
        {
            tbMessageLog.AppendText("\r\n" + "\r\n" +
                "You grip the rope tightly and use what little strength you have left to pull yourself up and out of the hole. " +
                "You fall to your knees as you reach the exit of the Pyramid, sucking in the cold desert air. " +
                "You realize you have to tell your crew everything you just experienced, and chastize them for not sending help in after you. " +
                "You stand up and run through the sand until you reach the tent, bursting through it. Everyone seems shocked at the state of you. " +
                "You frantically recount your experiences to your collegues as you escort them back to the Pyramid. " +
                "When you go to show them the hole you fell in, there is nothing there. " +
                "\r\n" + "\r\n" + "You have completed the game. Thank you for playing!");
            tbCommandLine.Text = "";
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            //NORTH
            if (tbCommandLine.Text == "n" || tbCommandLine.Text == "north" || tbCommandLine.Text == "up")
            {
                if (location == "Exploration Exodus - Q1")
                {
                    if (grapple == true)
                    {
                        gameComplete();
                    }
                    else
                    {
                        notMove("North");
                    }
                }
                else if (location == "Golden Doorway - Q2")
                {
                    if (Q2complete == false && Q1complete == false)
                    {
                        move("North", pbQ2, pbQ1, Properties.Resources.incomp, Properties.Resources.incompThere, "Exploration Exodus - Q1");
                    }
                    else if (Q2complete == true && Q1complete == false)
                    {
                        move("North", pbQ2, pbQ1, Properties.Resources.complete, Properties.Resources.incompThere, "Exploration Exodus - Q1");
                    }
                    else if (Q2complete == false && Q1complete == true)
                    {
                        move("North", pbQ2, pbQ1, Properties.Resources.incomp, Properties.Resources.completeThere, "Exploration Exodus - Q1");
                    }
                    else if (Q2complete == true && Q1complete == true)
                    {
                        move("North", pbQ2, pbQ1, Properties.Resources.complete, Properties.Resources.completeThere, "Exploration Exodus - Q1");
                    }
                }
                else if (location == "Dark Chasm - Q3")
                {
                    notMove("North");
                }
                else if (location == "Forked Passageway - Q4")
                {
                    if (Q4complete == false && Q3complete == false)
                    {
                        move("North", pbQ4, pbQ3, Properties.Resources.incomp, Properties.Resources.incompThere, "Dark Chasm - Q3");
                    }
                    else if (Q4complete == true && Q3complete == false)
                    {
                        move("North", pbQ4, pbQ3, Properties.Resources.complete, Properties.Resources.incompThere, "Dark Chasm - Q3");
                    }
                    else if (Q4complete == false && Q3complete == true)
                    {
                        move("North", pbQ4, pbQ3, Properties.Resources.incomp, Properties.Resources.completeThere, "Dark Chasm - Q3");
                    }
                    else if (Q4complete == true && Q3complete == true)
                    {
                        move("North", pbQ4, pbQ3, Properties.Resources.complete, Properties.Resources.completeThere, "Dark Chasm - Q3");
                    }
                }
                else if (location == "Ancient Armory - Q5")
                {
                    notMove("North");
                }
                else if (location == "The Mausoleum - Q6")
                {
                    if (Q6complete == false && Q5complete == false)
                    {
                        move("North", pbQ6, pbQ5, Properties.Resources.incomp, Properties.Resources.incompThere, "Ancient Armory - Q5");
                    }
                    else if (Q6complete == true && Q5complete == false)
                    {
                        move("North", pbQ6, pbQ5, Properties.Resources.complete, Properties.Resources.incompThere, "Ancient Armory - Q5");
                    }
                    else if (Q6complete == false && Q5complete == true)
                    {
                        move("North", pbQ6, pbQ5, Properties.Resources.incomp, Properties.Resources.completeThere, "Ancient Armory - Q5");
                    }
                    else if (Q6complete == true && Q5complete == true)
                    {
                        move("North", pbQ6, pbQ5, Properties.Resources.complete, Properties.Resources.completeThere, "Ancient Armory - Q5");
                    }
                }
                else if (location == "Guardian's Gate - Q7")
                {

                }
                else if (location == "Hall of Murals - Q8")
                {

                }
                else if (location == "Eye of Ra - Q9")
                {

                }
                else if (location == "Neith's Nest - Q10")
                {

                }
                else if (location == "Starlight Shaft - Q11")
                {

                }
                else if (location == "A'aru Banquet - Q12")
                {

                }
                else if (location == "Storage Chamber - Q13")
                {

                }
                else if (location == "Grip of Osiris - Q14")
                {

                }
                else if (location == "Pharaoh's Sanctum - Q15")
                {

                }
            }

            //SOUTH
            else if (tbCommandLine.Text == "s" || tbCommandLine.Text == "south" || tbCommandLine.Text == "down")
            {
                if (location == "Exploration Exodus - Q1")
                {
                    if (Q1complete == false && Q2complete == false)
                    {
                        move("South", pbQ1, pbQ2, Properties.Resources.incomp, Properties.Resources.incompThere, "Golden Doorway - Q2");
                        if (Q2entered == false)
                        {
                            Q2entered = true;
                            tbMessageLog.AppendText("\r\n" + "\r\n" + Q2text);
                        }
                    }
                    else if (Q1complete == true && Q2complete == false)
                    {
                        move("South", pbQ1, pbQ2, Properties.Resources.complete, Properties.Resources.incompThere, "Golden Doorway - Q2");
                        if (Q2entered == false)
                        {
                            Q2entered = true;
                            tbMessageLog.AppendText("\r\n" + "\r\n" + Q2text);
                        }
                    }
                    else if (Q1complete == false && Q2complete == true)
                    {
                        move("South", pbQ1, pbQ2, Properties.Resources.incomp, Properties.Resources.completeThere, "Golden Doorway - Q2");
                        if (Q2entered == false)
                        {
                            Q2entered = true;
                            tbMessageLog.AppendText("\r\n" + "\r\n" + Q2text);
                        }
                    }
                    else if (Q1complete == true && Q2complete == true)
                    {
                        move("South", pbQ1, pbQ2, Properties.Resources.complete, Properties.Resources.completeThere, "Golden Doorway - Q2");
                        if (Q2entered == false)
                        {
                            Q2entered = true;
                            tbMessageLog.AppendText("\r\n" + "\r\n" + Q2text);
                        }
                    }
                }
                else if (location == "Golden Doorway - Q2")
                {
                    if (wall == true)
                    {
                        if (Q2complete == false && Q15complete == false)
                        {
                            move("South", pbQ1, pbQ2, Properties.Resources.incomp, Properties.Resources.incompThere, "Pharaoh's Sanctum - Q15");
                        }
                        else if (Q2complete == true && Q15complete == false)
                        {
                            move("South", pbQ1, pbQ2, Properties.Resources.complete, Properties.Resources.incompThere, "Pharaoh's Sanctum - Q15");
                        }
                        else if (Q2complete == false && Q15complete == true)
                        {
                            move("South", pbQ1, pbQ2, Properties.Resources.incomp, Properties.Resources.completeThere, "Pharaoh's Sanctum - Q15");
                        }
                        else if (Q2complete == true && Q15complete == true)
                        {
                            move("South", pbQ1, pbQ2, Properties.Resources.complete, Properties.Resources.completeThere, "Pharaoh's Sanctum - Q15");
                        }
                    }
                    else
                    {
                        notMove("South");
                    }
                }
                else if (location == "Dark Chasm - Q3")
                {
                    if (bridge == true)
                    {
                        if (Q3complete == false && Q4complete == false)
                        {
                            move("South", pbQ3, pbQ4, Properties.Resources.incomp, Properties.Resources.incompThere, "Forked Passageway - Q4");
                            if (Q4entered == false)
                            {
                                Q4entered = true;
                                tbMessageLog.AppendText("\r\n" + "\r\n" + Q4text);
                            }
                        }
                        else if (Q3complete == true && Q4complete == false)
                        {
                            move("South", pbQ3, pbQ4, Properties.Resources.complete, Properties.Resources.incompThere, "Forked Passageway - Q4");
                            if (Q4entered == false)
                            {
                                Q4entered = true;
                                tbMessageLog.AppendText("\r\n" + "\r\n" + Q4text);
                            }
                        }
                        else if (Q3complete == false && Q4complete == true)
                        {
                            move("South", pbQ3, pbQ4, Properties.Resources.incomp, Properties.Resources.completeThere, "Forked Passageway - Q4");
                            if (Q4entered == false)
                            {
                                Q4entered = true;
                                tbMessageLog.AppendText("\r\n" + "\r\n" + Q4text);
                            }
                        }
                        else if (Q3complete == true && Q4complete == true)
                        {
                            move("South", pbQ3, pbQ4, Properties.Resources.complete, Properties.Resources.completeThere, "Forked Passageway - Q4");
                            if (Q4entered == false)
                            {
                                Q4entered = true;
                                tbMessageLog.AppendText("\r\n" + "\r\n" + Q4text);
                            }
                        }
                    }
                    else
                    {
                        notMove("South");
                    }
                }
                else if (location == "Forked Passageway - Q4")
                {
                    notMove("South");
                }
                else if (location == "Ancient Armory - Q5")
                {
                    if (Q5complete == false && Q6complete == false)
                    {
                        move("South", pbQ5, pbQ6, Properties.Resources.incomp, Properties.Resources.incompThere, "The Mausoleum - Q6");
                        if (Q6entered == false)
                        {
                            Q6entered = true;
                            tbMessageLog.AppendText("\r\n" + "\r\n" + Q6text);
                        }
                    }
                    else if (Q5complete == true && Q6complete == false)
                    {
                        move("South", pbQ5, pbQ6, Properties.Resources.complete, Properties.Resources.incompThere, "The Mausoleum - Q6");
                        if (Q6entered == false)
                        {
                            Q6entered = true;
                            tbMessageLog.AppendText("\r\n" + "\r\n" + Q6text);
                        }
                    }
                    else if (Q5complete == false && Q6complete == true)
                    {
                        move("South", pbQ5, pbQ6, Properties.Resources.incomp, Properties.Resources.completeThere, "The Mausoleum - Q6");
                        if (Q6entered == false)
                        {
                            Q6entered = true;
                            tbMessageLog.AppendText("\r\n" + "\r\n" + Q6text);
                        }
                    }
                    else if (Q5complete == true && Q6complete == true)
                    {
                        move("South", pbQ5, pbQ6, Properties.Resources.complete, Properties.Resources.completeThere, "The Mausoleum - Q6");
                        if (Q6entered == false)
                        {
                            Q6entered = true;
                            tbMessageLog.AppendText("\r\n" + "\r\n" + Q6text);
                        }
                    }
                }
                else if (location == "The Mausoleum - Q6")
                {
                    notMove("South");
                }
                else if (location == "Guardian's Gate - Q7")
                {

                }
                else if (location == "Hall of Murals - Q8")
                {

                }
                else if (location == "Eye of Ra - Q9")
                {

                }
                else if (location == "Neith's Nest - Q10")
                {

                }
                else if (location == "Starlight Shaft - Q11")
                {

                }
                else if (location == "A'aru Banquet - Q12")
                {

                }
                else if (location == "Storage Chamber - Q13")
                {

                }
                else if (location == "Grip of Osiris - Q14")
                {

                }
                else if (location == "Pharaoh's Sanctum - Q15")
                {

                }
            }

            //EAST
            else if (tbCommandLine.Text == "e" || tbCommandLine.Text == "east" || tbCommandLine.Text == "right")
            {
                if (location == "Exploration Exodus - Q1")
                {
                    notMove("East");
                }
                else if (location == "Golden Doorway - Q2")
                {
                    notMove("East");
                }
                else if (location == "Dark Chasm - Q3")
                {
                    if (Q3complete == false && Q2complete == false)
                    {
                        move("East", pbQ3, pbQ2, Properties.Resources.incomp, Properties.Resources.incompThere, "Golden Doorway - Q2");
                    }
                    else if (Q3complete == true && Q2complete == false)
                    {
                        move("East", pbQ3, pbQ2, Properties.Resources.complete, Properties.Resources.incompThere, "Golden Doorway - Q2");
                    }
                    else if (Q3complete == false && Q2complete == true)
                    {
                        move("East", pbQ3, pbQ2, Properties.Resources.incomp, Properties.Resources.completeThere, "Golden Doorway - Q2");
                    }
                    else if (Q3complete == true && Q2complete == true)
                    {
                        move("East", pbQ3, pbQ2, Properties.Resources.complete, Properties.Resources.completeThere, "Golden Doorway - Q2");
                    }
                }
                else if (location == "Forked Passageway - Q4")
                {
                    if (Q4complete == false && Q7complete == false)
                    {
                        move("East", pbQ4, pbQ7, Properties.Resources.incomp, Properties.Resources.incompThere, "Guardian's Gate - Q7");
                        if (Q7entered == false)
                        {
                            Q7entered = true;
                            tbMessageLog.AppendText("\r\n" + "\r\n" + Q7text);
                        }
                    }
                    else if (Q4complete == true && Q7complete == false)
                    {
                        move("East", pbQ4, pbQ7, Properties.Resources.complete, Properties.Resources.incompThere, "Guardian's Gate - Q7");
                        if (Q7entered == false)
                        {
                            Q7entered = true;
                            tbMessageLog.AppendText("\r\n" + "\r\n" + Q7text);
                        }
                    }
                    else if (Q4complete == false && Q7complete == true)
                    {
                        move("East", pbQ4, pbQ7, Properties.Resources.incomp, Properties.Resources.completeThere, "Guardian's Gate - Q7");
                        if (Q7entered == false)
                        {
                            Q7entered = true;
                            tbMessageLog.AppendText("\r\n" + "\r\n" + Q7text);
                        }
                    }
                    else if (Q4complete == true && Q7complete == true)
                    {
                        move("East", pbQ4, pbQ7, Properties.Resources.complete, Properties.Resources.completeThere, "Guardian's Gate - Q7");
                        if (Q7entered == false)
                        {
                            Q7entered = true;
                            tbMessageLog.AppendText("\r\n" + "\r\n" + Q7text);
                        }
                    }
                }
                else if (location == "Ancient Armory - Q5")
                {
                    if (Q5complete == false && Q4complete == false)
                    {
                        move("East", pbQ5, pbQ4, Properties.Resources.incomp, Properties.Resources.incompThere, "Forked Passageway - Q4");
                    }
                    else if (Q5complete == true && Q4complete == false)
                    {
                        move("East", pbQ5, pbQ4, Properties.Resources.complete, Properties.Resources.incompThere, "Forked Passageway - Q4");
                    }
                    else if (Q5complete == false && Q4complete == true)
                    {
                        move("East", pbQ5, pbQ4, Properties.Resources.incomp, Properties.Resources.completeThere, "Forked Passageway - Q4");
                    }
                    else if (Q5complete == true && Q4complete == true)
                    {
                        move("East", pbQ5, pbQ4, Properties.Resources.complete, Properties.Resources.completeThere, "Forked Passageway - Q4");
                    }
                }
                else if (location == "The Mausoleum - Q6")
                {
                    notMove("East");
                }
                else if (location == "Guardian's Gate - Q7")
                {

                }
                else if (location == "Hall of Murals - Q8")
                {

                }
                else if (location == "Eye of Ra - Q9")
                {

                }
                else if (location == "Neith's Nest - Q10")
                {

                }
                else if (location == "Starlight Shaft - Q11")
                {

                }
                else if (location == "A'aru Banquet - Q12")
                {

                }
                else if (location == "Storage Chamber - Q13")
                {

                }
                else if (location == "Grip of Osiris - Q14")
                {

                }
                else if (location == "Pharaoh's Sanctum - Q15")
                {

                }
            }

            //WEST
            else if (tbCommandLine.Text == "w" || tbCommandLine.Text == "west" || tbCommandLine.Text == "left")
            {
                if (location == "Exploration Exodus - Q1")
                {
                    notMove("West");
                }
                else if (location == "Golden Doorway - Q2")
                {
                    if (door == true)
                    {
                        if (Q2complete == false && Q3complete == false)
                        {
                            move("West", pbQ2, pbQ3, Properties.Resources.incomp, Properties.Resources.incompThere, "Dark Chasm - Q3");
                            if (Q3entered == false)
                            {
                                Q3entered = true;
                                tbMessageLog.AppendText("\r\n" + "\r\n" + Q3text);
                            }
                        }
                        else if (Q2complete == true && Q3complete == false)
                        {
                            move("West", pbQ2, pbQ3, Properties.Resources.complete, Properties.Resources.incompThere, "Dark Chasm - Q3");
                            if (Q3entered == false)
                            {
                                Q3entered = true;
                                tbMessageLog.AppendText("\r\n" + "\r\n" + Q3text);
                            }
                        }
                        else if (Q2complete == false && Q3complete == true)
                        {
                            move("West", pbQ2, pbQ3, Properties.Resources.incomp, Properties.Resources.completeThere, "Dark Chasm - Q3");
                            if (Q3entered == false)
                            {
                                Q3entered = true;
                                tbMessageLog.AppendText("\r\n" + "\r\n" + Q3text);
                            }
                        }
                        else if (Q2complete == true && Q3complete == true)
                        {
                            move("West", pbQ2, pbQ3, Properties.Resources.complete, Properties.Resources.completeThere, "Dark Chasm - Q3");
                            if (Q3entered == false)
                            {
                                Q3entered = true;
                                tbMessageLog.AppendText("\r\n" + "\r\n" + Q3text);
                            }
                        }
                    }
                    else
                    {
                        notMove("West");
                    }
                }
                else if (location == "Dark Chasm - Q3")
                {
                    notMove("West");
                }
                else if (location == "Forked Passageway - Q4")
                {
                    if (Q4complete == false && Q5complete == false)
                    {
                        move("East", pbQ4, pbQ5, Properties.Resources.incomp, Properties.Resources.incompThere, "Ancient Armory - Q5");
                        if (Q5entered == false)
                        {
                            Q5entered = true;
                            tbMessageLog.AppendText("\r\n" + "\r\n" + Q5text);
                        }
                    }
                    else if (Q4complete == true && Q5complete == false)
                    {
                        move("East", pbQ4, pbQ5, Properties.Resources.complete, Properties.Resources.incompThere, "Ancient Armory - Q5");
                        if (Q5entered == false)
                        {
                            Q5entered = true;
                            tbMessageLog.AppendText("\r\n" + "\r\n" + Q5text);
                        }
                    }
                    else if (Q4complete == false && Q5complete == true)
                    {
                        move("East", pbQ4, pbQ5, Properties.Resources.incomp, Properties.Resources.completeThere, "Ancient Armory - Q5");
                        if (Q5entered == false)
                        {
                            Q5entered = true;
                            tbMessageLog.AppendText("\r\n" + "\r\n" + Q5text);
                        }
                    }
                    else if (Q4complete == true && Q5complete == true)
                    {
                        move("East", pbQ4, pbQ5, Properties.Resources.complete, Properties.Resources.completeThere, "Ancient Armory - Q5");
                        if (Q5entered == false)
                        {
                            Q5entered = true;
                            tbMessageLog.AppendText("\r\n" + "\r\n" + Q5text);
                        }
                    }
                }
                else if (location == "Ancient Armory - Q5")
                {
                    notMove("West");
                }
                else if (location == "The Mausoleum - Q6")
                {
                    notMove("West");
                }
                else if (location == "Guardian's Gate - Q7")
                {

                }
                else if (location == "Hall of Murals - Q8")
                {

                }
                else if (location == "Eye of Ra - Q9")
                {

                }
                else if (location == "Neith's Nest - Q10")
                {

                }
                else if (location == "Starlight Shaft - Q11")
                {

                }
                else if (location == "A'aru Banquet - Q12")
                {

                }
                else if (location == "Storage Chamber - Q13")
                {

                }
                else if (location == "Grip of Osiris - Q14")
                {

                }
                else if (location == "Pharaoh's Sanctum - Q15")
                {

                }
            }

            //LOOK +
            else if (tbCommandLine.Text == "look")
            {
                if (location == "Exploration Exodus - Q1")
                {
                    look(Q1look);
                }
                else if (location == "Golden Doorway - Q2")
                {
                    look(Q2look);
                }
                else if (location == "Dark Chasm - Q3")
                {
                    look(Q3look);
                }
                else if (location == "Forked Passageway - Q4")
                {
                    look(Q4look);
                }
                else if (location == "Ancient Armory - Q5")
                {
                    look(Q5look);
                }
                else if (location == "The Mausoleum - Q6")
                {
                    look(Q6look);
                }
                else if (location == "Guardian's Gate - Q7")
                {
                    look(Q7look);
                }
                else if (location == "Hall of Murals - Q8")
                {
                    look(Q8look);
                }
                else if (location == "Eye of Ra - Q9")
                {
                    look(Q9look);
                }
                else if (location == "Neith's Nest - Q10")
                {
                    look(Q10look);
                }
                else if (location == "Starlight Shaft - Q11")
                {
                    look(Q11look);
                }
                else if (location == "A'aru Banquet - Q12")
                {
                    look(Q12look);
                }
                else if (location == "Storage Chamber - Q13")
                {
                    look(Q13look);
                }
                else if (location == "Grip of Osiris - Q14")
                {
                    look(Q14look);
                }
                else if (location == "Pharaoh's Sanctum - Q15")
                {
                    look(Q15look);
                }
            }

            //TAKE +
            else if (tbCommandLine.Text == "take wooden plank" || tbCommandLine.Text == "take plank")
            {
                if (location == "Exploration Exodus - Q1")
                {
                    if (woodenPlank == false)
                    {
                        woodenPlank = true;
                        tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "You took the wooden plank.");
                        tbCommandLine.Text = "";
                    }
                    else
                    {
                        tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "You already took the wooden plank.");
                        tbCommandLine.Text = "";
                    }
                }
                else
                {
                    tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "There is no wooden plank to take here.");
                    tbCommandLine.Text = "";
                }
            }
            else if (tbCommandLine.Text == "take golden key" || tbCommandLine.Text == "take key")
            {
                if (location == "Golden Doorway - Q2")
                {
                    if (goldenKey == false)
                    {
                        goldenKey = true;
                        tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "You took the golden key.");
                        tbCommandLine.Text = "";
                    }
                    else
                    {
                        tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "You already took the golden key.");
                        tbCommandLine.Text = "";
                    }
                }
                else
                {
                    tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "There is no golden key to take here.");
                    tbCommandLine.Text = "";
                }
            }
            else if (tbCommandLine.Text == "take rusty sword" || tbCommandLine.Text == "take sword")
            {
                if (location == "Ancient Armory - Q5")
                {
                    if (rustySword == false)
                    {
                        rustySword = true;
                        Q5complete = true;
                        pbQ5.Image = Properties.Resources.completeThere;
                        tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "You took the rusty sword.");
                        tbCommandLine.Text = "";
                    }
                    else
                    {
                        tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "You already took the rusty sword.");
                        tbCommandLine.Text = "";
                    }
                }
                else
                {
                    tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "There is no rusty sword to take here.");
                    tbCommandLine.Text = "";
                }
            }
            else if (tbCommandLine.Text == "take burning torch" || tbCommandLine.Text == "take torch")
            {
                if (location == "Eye of Ra - Q9")
                {
                    if (burningTorch == false)
                    {
                        burningTorch = true;
                        Q9complete = true;
                        pbQ9.Image = Properties.Resources.completeThere;
                        tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "You took the burning torch.");
                        tbCommandLine.Text = "";
                    }
                    else
                    {
                        tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "You already took the burning torch.");
                        tbCommandLine.Text = "";
                    }
                }
                else
                {
                    tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "There is no burning torch to take here.");
                    tbCommandLine.Text = "";
                }
            }
            else if (tbCommandLine.Text == "take ancient bread" || tbCommandLine.Text == "take bread")
            {
                if (location == "A'aru Banquet - Q12")
                {
                    if (ancientBread == false)
                    {
                        ancientBread = true;
                        Q12complete = true;
                        pbQ12.Image = Properties.Resources.completeThere;
                        tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "You took the ancient bread.");
                        tbCommandLine.Text = "";
                    }
                    else
                    {
                        tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "You already took the ancient bread.");
                        tbCommandLine.Text = "";
                    }
                }
                else
                {
                    tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "There is no ancient bread to take here.");
                    tbCommandLine.Text = "";
                }
            }
            else if (tbCommandLine.Text == "take worker's axe" || tbCommandLine.Text == "take axe" || tbCommandLine.Text == "workers axe")
            {
                if (location == "Storage Chamber - Q13")
                {
                    if (workersAxe == false)
                    {
                        workersAxe = true;
                        Q13complete = true;
                        pbQ13.Image = Properties.Resources.completeThere;
                        tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "You took the worker's axe.");
                        tbCommandLine.Text = "";
                    }
                    else
                    {
                        tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "You already took the worker's axe.");
                        tbCommandLine.Text = "";
                    }
                }
                else
                {
                    tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "There is no worker's axe to take here.");
                    tbCommandLine.Text = "";
                }
            }
            else if (tbCommandLine.Text == "take grappling hook" || tbCommandLine.Text == "take hook")
            {
                if (location == "Pharaoh's Sanctum - Q15")
                {
                    if (grapplingHook == false)
                    {
                        grapplingHook = true;
                        if (wall == true)
                        {
                            Q15complete = true;
                            pbQ15.Image = Properties.Resources.completeThere;
                        }
                        tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "You took the grappling hook.");
                        tbCommandLine.Text = "";
                    }
                    else
                    {
                        tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "You already took the grappling hook.");
                        tbCommandLine.Text = "";
                    }
                }
                else
                {
                    tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "There is no grappling hook to take here.");
                    tbCommandLine.Text = "";
                }
            }
            else if (tbCommandLine.Text == "take")
            {
                tbMessageLog.AppendText("\r\n" + "\r\n"
                        + "You typed: "
                        + tbCommandLine.Text + "\r\n"
                        + "What do you want to take? (Type 'take' + the name of the item.)");
                tbCommandLine.Text = "";
            }

            //USE +
            else if (tbCommandLine.Text == "use")
            {
                if (location == "Exploration Exodus - Q1")
                {
                    if (grapplingHook == true)
                    {
                        grapple = true;
                        Q1complete = true;
                        pbQ1.Image = Properties.Resources.completeThere;
                        tbMessageLog.AppendText("\r\n" + "\r\n" + "You typed: " + tbCommandLine.Text + "\r\n" +
                            "You use the grappling hook to cling to the edge of the hole you fell in through. " +
                            "You can finally climb up and escape this cursed labyrinth.");
                        tbCommandLine.Text = "";
                    }
                    else
                    {
                        tbMessageLog.AppendText("\r\n" + "\r\n" + 
                            "You typed: " + tbCommandLine.Text + 
                            "\r\n" + "You don't seem to have the item you need here yet. " +
                            "You can see light seeping in from the hole you fell through, " +
                            "but it is far to high up for you to climb on your own.");
                        tbCommandLine.Text = "";
                    }
                }
                else if (location == "Golden Doorway - Q2")
                {
                    if (goldenKey == true)
                    {
                        door = true;
                        Q2complete = true;
                        pbQ2.Image = Properties.Resources.completeThere;
                        tbMessageLog.AppendText("\r\n" + "\r\n" + "You typed: " + tbCommandLine.Text + "\r\n" +
                            "You use the golden key to unlock the large door. " +
                            "There is a satisfying clunk as the key is turned. " +
                            "You can now use push through and travel to the West.");
                        tbCommandLine.Text = "";
                    }
                    else
                    {
                        tbMessageLog.AppendText("\r\n" + "\r\n" +
                            "You typed: " + tbCommandLine.Text +
                            "\r\n" + "You don't seem to have the item you need here yet. " +
                            "The large, heavy door is sealed tightly, " +
                            "but there is a large keyhole in the center.");
                        tbCommandLine.Text = "";
                    }
                }
                else if (location == "Dark Chasm - Q3")
                {
                    if (woodenPlank == true)
                    {
                        bridge = true;
                        Q3complete = true;
                        Q4complete = true;
                        pbQ3.Image = Properties.Resources.completeThere;
                        pbBridge.Image = Properties.Resources.bridge1;
                        tbMessageLog.AppendText("\r\n" + "\r\n" + "You typed: " + tbCommandLine.Text + "\r\n" +
                            "You place the wooden plank down to create a bridge across the abyss. " +
                            "You can now walk across it to reach the room to the South.");
                        tbCommandLine.Text = "";
                    }
                    else
                    {
                        tbMessageLog.AppendText("\r\n" + "\r\n" +
                            "You typed: " + tbCommandLine.Text +
                            "\r\n" + "You don't seem to have the item you need here yet. " +
                            "The abyss below is far too wide for you to jump. " +
                            "There must be another way across this gap.");
                        tbCommandLine.Text = "";
                    }
                }
                else if (location == "Forked Passageway - Q4")
                {
                    tbMessageLog.AppendText("\r\n" + "\r\n" + "You can't see a way to use an item here. " +
                        "There are passages to your East and West that may hold the secrets to the way forward. ");
                    tbCommandLine.Text = "";
                }
                else if (location == "Ancient Armory - Q5")
                {
                    tbMessageLog.AppendText("\r\n" + "\r\n" + "You can't see a way to use an item here. " +
                        "A deep sense of dread fills the air.");
                    tbCommandLine.Text = "";
                }
                else if (location == "The Mausoleum - Q6")
                {
                    if (rustySword == true)
                    {
                        mummy = true;
                        Q6complete = true;
                        pbQ6.Image = Properties.Resources.completeThere;
                        tbMessageLog.AppendText("\r\n" + "\r\n" + "You typed: " + tbCommandLine.Text + "\r\n" +
                            "You grip the curved bronze blade tightly and slash through the imposing Undead. " +
                            "It groans and withers into dust. A gust of cold wind blows away the remains, " +
                            "revealing a shining gemstone where it stood. " +
                            "You take the shining gemstone.");
                        shiningGemstone = true;
                        tbCommandLine.Text = "";
                    }
                    else
                    {
                        tbMessageLog.AppendText("\r\n" + "\r\n" +
                            "You typed: " + tbCommandLine.Text +
                            "\r\n" + "You don't seem to have the item you need here yet. " +
                            "This abomination is too powerful for you to slay with your own hands, " +
                            "but it does not seem interested in an unfair fight. " +
                            "You get the sense that you must return better prepared.");
                        tbCommandLine.Text = "";
                    }
                }
                else if (location == "Guardian's Gate - Q7")
                {
                    if (shiningGemstone == true)
                    {
                        statue = true;
                        Q7complete = true;
                        pbQ7.Image = Properties.Resources.completeThere;
                        tbMessageLog.AppendText("\r\n" + "\r\n" + "You typed: " + tbCommandLine.Text + "\r\n" +
                            "You take the shining gemstone and insert it into the empty socket of the statue. " +
                            "Now complete, its emerald eyes seem to flash. The doglike head begins to slowly turn, " +
                            "filling your ears with the sound of grinding stone as it points South. " +
                            "The wall standing there just moments ago has vanished.");
                        tbCommandLine.Text = "";
                    }
                    else
                    {
                        tbMessageLog.AppendText("\r\n" + "\r\n" +
                            "You typed: " + tbCommandLine.Text +
                            "\r\n" + "You don't seem to have the item you need here yet. " +
                            "The emerald stare of the looming beast is incomplete. " +
                            "You feel as though it is expecting something of you. ");
                        tbCommandLine.Text = "";
                    }
                }
                else if (location == "Hall of Murals - Q8")
                {
                    tbMessageLog.AppendText("\r\n" + "\r\n" + "You can't see a way to use an item here. " +
                        "Light and heat are pouring in from the Eastern doorway.");
                    tbCommandLine.Text = "";
                }
                else if (location == "Eye of Ra - Q9")
                {
                    tbMessageLog.AppendText("\r\n" + "\r\n" + "You can't see a way to use an item here. " +
                        "The heat of this room is becoming difficult to withstand, " +
                        "as if emanating from the Sun itself.");
                    tbCommandLine.Text = "";
                }
                else if (location == "Neith's Nest - Q10")
                {
                    if (burningTorch == true)
                    {
                        webs = true;
                        Q10complete = true;
                        pbQ10.Image = Properties.Resources.completeThere;
                        tbMessageLog.AppendText("\r\n" + "\r\n" + "You typed: " + tbCommandLine.Text + "\r\n" +
                            "You touch the raging flame of the torch to the blanket of thick webbing " +
                            "and watch as the fire runs along its patterns. " +
                            "In a matter of seconds, the webs are erased and the way North is clear.");
                        tbCommandLine.Text = "";
                    }
                    else
                    {
                        tbMessageLog.AppendText("\r\n" + "\r\n" +
                            "You typed: " + tbCommandLine.Text +
                            "\r\n" + "You don't seem to have the item you need here yet. " +
                            "The emerald stare of the looming beast is incomplete. " +
                            "You feel as though it is expecting something of you. ");
                        tbCommandLine.Text = "";
                    }
                }
                else if (location == "Starlight Shaft - Q11")
                {
                    tbMessageLog.AppendText("\r\n" + "\r\n" + "You can't see a way to use an item here. " +
                        "The tight corridor barely leaves enough room to squeeze through it. " +
                        "The chill of the night runs through your body, urging you to continue onward.");
                    tbCommandLine.Text = "";
                }
                else if (location == "A'aru Banquet - Q12")
                {
                    tbMessageLog.AppendText("\r\n" + "\r\n" + "You can't see a way to use an item here. " +
                        "You feel as though you are not alone in this room. " +
                        "It seems best to take what you need and avoid disturbing the reeds any further. " +
                        "There are halls leading to the North and West.");
                    tbCommandLine.Text = "";
                }
                else if (location == "Storage Chamber - Q13")
                {
                    tbMessageLog.AppendText("\r\n" + "\r\n" + "You can't see a way to use an item here. " +
                        "It seems like this room was for storing mundane tools and nothing more. " +
                        "You feel exhausted. Your breathing is becoming more labored the longer you linger here.");
                    tbCommandLine.Text = "";
                }
                else if (location == "Grip of Osiris - Q14")
                {
                    if (ancientBread == true)
                    {
                        osiris = true;
                        Q14complete = true;
                        pbQ14.Image = Properties.Resources.completeThere;
                        tbMessageLog.AppendText("\r\n" + "\r\n" + "You typed: " + tbCommandLine.Text + "\r\n" +
                            "You kneel and offer the food to the cold visage of death before you. " +
                            "It speaks to your soul, seemingly grateful. Before you have the chance to look up, " +
                            "the presence has already faded. Only now do you realize how stiff your body has become, " +
                            "and that a cold sweat has overtaken you. It takes a great effort to stand up, " +
                            "but you are free to descend the Eastern stairway into the final chamber now.");
                        tbCommandLine.Text = "";
                    }
                    else
                    {
                        tbMessageLog.AppendText("\r\n" + "\r\n" +
                            "You typed: " + tbCommandLine.Text +
                            "\r\n" + "You don't seem to have the item you need here yet. " +
                            "Your senses are assaulted with a foul odor and you retch. " +
                            "You feel rejected by the presence. It demands something from you. ");
                        tbCommandLine.Text = "";
                    }
                }
                else if (location == "Pharaoh's Sanctum - Q15")
                {
                    if (workersAxe == true)
                    {
                        wall = true;
                        if (grapplingHook == true)
                        {
                            Q15complete = true;
                            pbQ15.Image = Properties.Resources.completeThere;
                        }
                        Q15complete = true;
                        pbQ15.Image = Properties.Resources.completeThere;
                        tbMessageLog.AppendText("\r\n" + "\r\n" + "You typed: " + tbCommandLine.Text + "\r\n" +
                            "You notice that the Northern wall of the Sanctum is actually just elaborately carved and painted wood. " +
                            "Desperate for escape, you put aside your hesitance to desecrate this tomb and attempt to chop through " +
                            "the wall with the worker's axe you found. Perhaps through adrenaline, you bust through rather easily " +
                            "and are greeted with the familiar image of a large golden door.");
                        tbCommandLine.Text = "";
                    }
                    else
                    {
                        tbMessageLog.AppendText("\r\n" + "\r\n" +
                            "You typed: " + tbCommandLine.Text +
                            "\r\n" + "You don't seem to have an item that would be useful here yet. " +
                            "You feel destructive.");
                        tbCommandLine.Text = "";
                    }
                }
            }

            //HELP +
            else if (tbCommandLine.Text == "help" || tbCommandLine.Text == "commands")
            {
                tbMessageLog.AppendText("\r\n" + "\r\n"
                    + "You typed: " + tbCommandLine.Text + "\r\n"
                    + "Here is a list of accepted commands:"
                    + "\r\n" + "('north' / 'n' / 'up')"
                    + "\r\n" + "('south' / 's' / 'down')"
                    + "\r\n" + "('east' / 'e' / 'right')"
                    + "\r\n" + "('west' / 'w' / 'left')"
                    + "\r\n" + "('take' + 'item name')"
                    + "\r\n" + "'use'"
                    + "\r\n" + "'hello'"
                    + "\r\n" + "'reset'"
                    + "\r\n" + "'end'");
                tbCommandLine.Text = "";
            }

            //HELLO +
            else if (tbCommandLine.Text == "hello" || tbCommandLine.Text == "hi")
            {
                tbMessageLog.AppendText("\r\n" + "\r\n"
                    + "You typed: " + tbCommandLine.Text + "\r\n" + "Hello!");
                tbCommandLine.Text = "";
            }

            //RESET +
            else if (tbCommandLine.Text == "reset")
            {
                reset();
            }

            //END +
            else if (tbCommandLine.Text == "end")
            {
                Application.Exit();
            }

            //ERROR HANDLING +
            else error();
        }

        private void resetMessageLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tbMessageLog.Text = "";
        }

        private void resetGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
