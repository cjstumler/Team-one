﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameCodeApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            //This is to set the initial location value.
            string loc = "BottomRight";

            if (tbCommand.Text == "hi there")
            {
                tbOutput.Text = tbOutput.Text + "\r\n" + "\r\n" + "You typed: " + tbCommand.Text + "\r\n" + "Hi there!";
                //pbTopLeft.Image = Properties.Resources.welcome;
                tbCommand.Text = "";
            }

            //These commands handle movement.
            else if (tbCommand.Text == "n" || tbCommand.Text == "north" || tbCommand.Text == "up")
            {
                if (loc == "BottomRight")
                {
                    tbOutput.Text = tbOutput.Text + "\r\n" + "\r\n" + "You typed: " + tbCommand.Text + "\r\n" + "You decide to go North.";
                    pbBottomRight.Image = Properties.Resources.halfLoc;
                    pbTopRight.Image = Properties.Resources.halfLocTHERE;
                    tbCommand.Text = "";
                    tbLocationName.Text = "TopRight";
                    loc = "TopRight";
                }
                else if (loc == "TopRight")
                {
                    tbOutput.Text = tbOutput.Text + "\r\n" + "\r\n" + "You typed: " + tbCommand.Text + "\r\n" + "You cannot go North. Please choose another action.";
                    //loc = "TopRight";
                }
                else if (loc == "BottomLeft")
                {
                    tbOutput.Text = tbOutput.Text + "\r\n" + "\r\n" + "You typed: " + tbCommand.Text + "\r\n" + "You decide to go North.";
                    pbBottomRight.Image = Properties.Resources.halfLoc;
                    pbTopRight.Image = Properties.Resources.halfLocTHERE;
                    tbCommand.Text = "";
                    tbLocationName.Text = "TopLeft";
                    loc = "TopLeft";
                }
                else if (loc == "TopLeft")
                {
                    tbOutput.Text = tbOutput.Text + "\r\n" + "\r\n" + "You typed: " + tbCommand.Text + "\r\n" + "You cannot go North. Please choose another action.";
                    //loc = "TopRight";
                }
            }
            else if (tbCommand.Text == "s" || tbCommand.Text == "south" || tbCommand.Text == "down")
            {
                if (loc == "BottomRight")
                {

                }
                else if (loc == "TopRight")
                {

                }
                else if (loc == "BottomLeft")
                {

                }
                else if (loc == "TopLeft")
                {

                }
            }
            else if (tbCommand.Text == "e" || tbCommand.Text == "east" || tbCommand.Text == "right")
            {
                if (loc == "BottomRight")
                {

                }
                else if (loc == "TopRight")
                {

                }
                else if (loc == "BottomLeft")
                {

                }
                else if (loc == "TopLeft")
                {

                }

            }
            else if (tbCommand.Text == "w" || tbCommand.Text == "west" || tbCommand.Text == "left")
            {
                if (loc == "BottomRight")
                {

                }
                else if (loc == "TopRight")
                {

                }
                else if (loc == "BottomLeft")
                {

                }
                else if (loc == "TopLeft")
                {

                }

            }

            //This will be the test "area complete" command.
            else if (tbCommand.Text == "complete")
            {
                if (loc == "BottomRight")
                {

                }
                else if (loc == "TopRight")
                {

                }
                else if (loc == "BottomLeft")
                {

                }
                else if (loc == "TopLeft")
                {

                }
            }

            //This is the help command.
            else if (tbCommand.Text == "help")
            {
                tbOutput.Text = tbOutput.Text + "\r\n" + "\r\n" + "You typed: " + tbCommand.Text + "\r\n" + "Here is a list of accepted commands: 'hi there', 'help'";
                //pbTopLeft.Image = Properties.Resources.welcome;
                tbCommand.Text = "";
            }

            //Throwing errors.
            else error();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ActiveControl = tbCommand;
        }

        private void error()
        {
            tbOutput.Text = tbOutput.Text + "\r\n" + "\r\n" + "There was an error. Check to make sure a valid command was entered.";
        }
    }
}
