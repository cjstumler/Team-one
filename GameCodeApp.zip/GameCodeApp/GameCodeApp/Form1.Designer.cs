﻿namespace GameCodeApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tbLocationName = new System.Windows.Forms.TextBox();
            this.pbTopLeft = new System.Windows.Forms.PictureBox();
            this.pbTopRight = new System.Windows.Forms.PictureBox();
            this.pbBottomLeft = new System.Windows.Forms.PictureBox();
            this.pbBottomRight = new System.Windows.Forms.PictureBox();
            this.btnEnter = new System.Windows.Forms.Button();
            this.tbCommand = new System.Windows.Forms.TextBox();
            this.tbOutput = new System.Windows.Forms.TextBox();
            this.gbCommand = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbTopLeft)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTopRight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBottomLeft)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBottomRight)).BeginInit();
            this.gbCommand.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbLocationName
            // 
            this.tbLocationName.BackColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.tbLocationName, "tbLocationName");
            this.tbLocationName.ForeColor = System.Drawing.Color.White;
            this.tbLocationName.Name = "tbLocationName";
            this.tbLocationName.ReadOnly = true;
            // 
            // pbTopLeft
            // 
            this.pbTopLeft.Image = global::GameCodeApp.Properties.Resources.newLoc;
            resources.ApplyResources(this.pbTopLeft, "pbTopLeft");
            this.pbTopLeft.Name = "pbTopLeft";
            this.pbTopLeft.TabStop = false;
            // 
            // pbTopRight
            // 
            this.pbTopRight.Image = global::GameCodeApp.Properties.Resources.newLoc;
            resources.ApplyResources(this.pbTopRight, "pbTopRight");
            this.pbTopRight.Name = "pbTopRight";
            this.pbTopRight.TabStop = false;
            // 
            // pbBottomLeft
            // 
            this.pbBottomLeft.Image = global::GameCodeApp.Properties.Resources.newLoc;
            resources.ApplyResources(this.pbBottomLeft, "pbBottomLeft");
            this.pbBottomLeft.Name = "pbBottomLeft";
            this.pbBottomLeft.TabStop = false;
            // 
            // pbBottomRight
            // 
            this.pbBottomRight.Image = global::GameCodeApp.Properties.Resources.halfLocTHERE;
            resources.ApplyResources(this.pbBottomRight, "pbBottomRight");
            this.pbBottomRight.Name = "pbBottomRight";
            this.pbBottomRight.TabStop = false;
            // 
            // btnEnter
            // 
            this.btnEnter.BackColor = System.Drawing.Color.SeaGreen;
            resources.ApplyResources(this.btnEnter, "btnEnter");
            this.btnEnter.ForeColor = System.Drawing.Color.White;
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.UseVisualStyleBackColor = false;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // tbCommand
            // 
            this.tbCommand.BackColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.tbCommand, "tbCommand");
            this.tbCommand.ForeColor = System.Drawing.Color.White;
            this.tbCommand.Name = "tbCommand";
            // 
            // tbOutput
            // 
            this.tbOutput.BackColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.tbOutput, "tbOutput");
            this.tbOutput.ForeColor = System.Drawing.Color.White;
            this.tbOutput.Name = "tbOutput";
            this.tbOutput.ReadOnly = true;
            // 
            // gbCommand
            // 
            this.gbCommand.Controls.Add(this.tbOutput);
            this.gbCommand.Controls.Add(this.btnEnter);
            this.gbCommand.ForeColor = System.Drawing.SystemColors.ControlText;
            resources.ApplyResources(this.gbCommand, "gbCommand");
            this.gbCommand.Name = "gbCommand";
            this.gbCommand.TabStop = false;
            // 
            // Form1
            // 
            this.AcceptButton = this.btnEnter;
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(123)))), ((int)(((byte)(92)))));
            this.Controls.Add(this.pbBottomRight);
            this.Controls.Add(this.tbCommand);
            this.Controls.Add(this.pbBottomLeft);
            this.Controls.Add(this.pbTopRight);
            this.Controls.Add(this.pbTopLeft);
            this.Controls.Add(this.tbLocationName);
            this.Controls.Add(this.gbCommand);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.HelpButton = true;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbTopLeft)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTopRight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBottomLeft)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBottomRight)).EndInit();
            this.gbCommand.ResumeLayout(false);
            this.gbCommand.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox tbLocationName;
        private System.Windows.Forms.PictureBox pbTopLeft;
        private System.Windows.Forms.PictureBox pbTopRight;
        private System.Windows.Forms.PictureBox pbBottomLeft;
        private System.Windows.Forms.PictureBox pbBottomRight;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.TextBox tbCommand;
        private System.Windows.Forms.TextBox tbOutput;
        private System.Windows.Forms.GroupBox gbCommand;
    }
}

