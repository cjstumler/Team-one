﻿namespace TextGameFinal
{
    partial class Pyramid
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbCommandLine = new System.Windows.Forms.TextBox();
            this.btnEnter = new System.Windows.Forms.Button();
            this.tbMessageLog = new System.Windows.Forms.TextBox();
            this.tbLocation = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.resetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetMessageLogToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pbQ1 = new System.Windows.Forms.PictureBox();
            this.pbQ2 = new System.Windows.Forms.PictureBox();
            this.pbQ3 = new System.Windows.Forms.PictureBox();
            this.pbBridge = new System.Windows.Forms.PictureBox();
            this.pbQ15 = new System.Windows.Forms.PictureBox();
            this.pbQ14 = new System.Windows.Forms.PictureBox();
            this.pbQ13 = new System.Windows.Forms.PictureBox();
            this.pbQ12 = new System.Windows.Forms.PictureBox();
            this.pbQ11 = new System.Windows.Forms.PictureBox();
            this.pbQ6 = new System.Windows.Forms.PictureBox();
            this.pbQ8 = new System.Windows.Forms.PictureBox();
            this.pbQ5 = new System.Windows.Forms.PictureBox();
            this.pbQ9 = new System.Windows.Forms.PictureBox();
            this.pbQ10 = new System.Windows.Forms.PictureBox();
            this.pbQ7 = new System.Windows.Forms.PictureBox();
            this.pbQ4 = new System.Windows.Forms.PictureBox();
            this.pbDecor1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBridge)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDecor1)).BeginInit();
            this.SuspendLayout();
            // 
            // tbCommandLine
            // 
            this.tbCommandLine.BackColor = System.Drawing.Color.Black;
            this.tbCommandLine.Font = new System.Drawing.Font("Perpetua", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbCommandLine.ForeColor = System.Drawing.Color.White;
            this.tbCommandLine.Location = new System.Drawing.Point(720, 775);
            this.tbCommandLine.Name = "tbCommandLine";
            this.tbCommandLine.Size = new System.Drawing.Size(384, 50);
            this.tbCommandLine.TabIndex = 0;
            // 
            // btnEnter
            // 
            this.btnEnter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(168)))), ((int)(((byte)(62)))));
            this.btnEnter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEnter.Font = new System.Drawing.Font("Papyrus", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnter.ForeColor = System.Drawing.Color.White;
            this.btnEnter.Location = new System.Drawing.Point(1110, 772);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(228, 55);
            this.btnEnter.TabIndex = 1;
            this.btnEnter.Text = "ENTER";
            this.btnEnter.UseVisualStyleBackColor = false;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // tbMessageLog
            // 
            this.tbMessageLog.BackColor = System.Drawing.Color.Black;
            this.tbMessageLog.Font = new System.Drawing.Font("Perpetua", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbMessageLog.ForeColor = System.Drawing.Color.White;
            this.tbMessageLog.Location = new System.Drawing.Point(720, 51);
            this.tbMessageLog.Multiline = true;
            this.tbMessageLog.Name = "tbMessageLog";
            this.tbMessageLog.ReadOnly = true;
            this.tbMessageLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbMessageLog.Size = new System.Drawing.Size(618, 715);
            this.tbMessageLog.TabIndex = 2;
            // 
            // tbLocation
            // 
            this.tbLocation.BackColor = System.Drawing.Color.Black;
            this.tbLocation.Font = new System.Drawing.Font("Papyrus", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbLocation.ForeColor = System.Drawing.Color.White;
            this.tbLocation.Location = new System.Drawing.Point(16, 51);
            this.tbLocation.Name = "tbLocation";
            this.tbLocation.ReadOnly = true;
            this.tbLocation.Size = new System.Drawing.Size(624, 59);
            this.tbLocation.TabIndex = 3;
            this.tbLocation.Text = "Exploration Exodus - Q1";
            this.tbLocation.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.White;
            this.menuStrip1.Font = new System.Drawing.Font("Perpetua", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.resetToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1353, 36);
            this.menuStrip1.TabIndex = 21;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // resetToolStripMenuItem
            // 
            this.resetToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.resetMessageLogToolStripMenuItem,
            this.resetGameToolStripMenuItem});
            this.resetToolStripMenuItem.Name = "resetToolStripMenuItem";
            this.resetToolStripMenuItem.Size = new System.Drawing.Size(75, 32);
            this.resetToolStripMenuItem.Text = "Reset";
            // 
            // resetMessageLogToolStripMenuItem
            // 
            this.resetMessageLogToolStripMenuItem.Name = "resetMessageLogToolStripMenuItem";
            this.resetMessageLogToolStripMenuItem.Size = new System.Drawing.Size(264, 32);
            this.resetMessageLogToolStripMenuItem.Text = "Reset Message Log";
            this.resetMessageLogToolStripMenuItem.Click += new System.EventHandler(this.resetMessageLogToolStripMenuItem_Click);
            // 
            // resetGameToolStripMenuItem
            // 
            this.resetGameToolStripMenuItem.Name = "resetGameToolStripMenuItem";
            this.resetGameToolStripMenuItem.Size = new System.Drawing.Size(264, 32);
            this.resetGameToolStripMenuItem.Text = "Reset Game";
            this.resetGameToolStripMenuItem.Click += new System.EventHandler(this.resetGameToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(62, 32);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // pbQ1
            // 
            this.pbQ1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbQ1.Image = global::TextGameFinal.Properties.Resources.incompThere;
            this.pbQ1.Location = new System.Drawing.Point(268, 203);
            this.pbQ1.Name = "pbQ1";
            this.pbQ1.Size = new System.Drawing.Size(120, 120);
            this.pbQ1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbQ1.TabIndex = 19;
            this.pbQ1.TabStop = false;
            // 
            // pbQ2
            // 
            this.pbQ2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbQ2.Image = global::TextGameFinal.Properties.Resources.undisc;
            this.pbQ2.Location = new System.Drawing.Point(268, 329);
            this.pbQ2.Name = "pbQ2";
            this.pbQ2.Size = new System.Drawing.Size(120, 120);
            this.pbQ2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbQ2.TabIndex = 18;
            this.pbQ2.TabStop = false;
            // 
            // pbQ3
            // 
            this.pbQ3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbQ3.Image = global::TextGameFinal.Properties.Resources.undisc;
            this.pbQ3.Location = new System.Drawing.Point(142, 329);
            this.pbQ3.Name = "pbQ3";
            this.pbQ3.Size = new System.Drawing.Size(120, 120);
            this.pbQ3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbQ3.TabIndex = 17;
            this.pbQ3.TabStop = false;
            // 
            // pbBridge
            // 
            this.pbBridge.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbBridge.Image = global::TextGameFinal.Properties.Resources.empty1;
            this.pbBridge.Location = new System.Drawing.Point(142, 455);
            this.pbBridge.Name = "pbBridge";
            this.pbBridge.Size = new System.Drawing.Size(120, 120);
            this.pbBridge.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbBridge.TabIndex = 16;
            this.pbBridge.TabStop = false;
            // 
            // pbQ15
            // 
            this.pbQ15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbQ15.Image = global::TextGameFinal.Properties.Resources.undisc;
            this.pbQ15.Location = new System.Drawing.Point(268, 455);
            this.pbQ15.Name = "pbQ15";
            this.pbQ15.Size = new System.Drawing.Size(120, 120);
            this.pbQ15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbQ15.TabIndex = 15;
            this.pbQ15.TabStop = false;
            // 
            // pbQ14
            // 
            this.pbQ14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbQ14.Image = global::TextGameFinal.Properties.Resources.undisc;
            this.pbQ14.Location = new System.Drawing.Point(394, 455);
            this.pbQ14.Name = "pbQ14";
            this.pbQ14.Size = new System.Drawing.Size(120, 120);
            this.pbQ14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbQ14.TabIndex = 14;
            this.pbQ14.TabStop = false;
            // 
            // pbQ13
            // 
            this.pbQ13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbQ13.Image = global::TextGameFinal.Properties.Resources.undisc;
            this.pbQ13.Location = new System.Drawing.Point(520, 329);
            this.pbQ13.Name = "pbQ13";
            this.pbQ13.Size = new System.Drawing.Size(120, 120);
            this.pbQ13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbQ13.TabIndex = 13;
            this.pbQ13.TabStop = false;
            // 
            // pbQ12
            // 
            this.pbQ12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbQ12.Image = global::TextGameFinal.Properties.Resources.undisc;
            this.pbQ12.Location = new System.Drawing.Point(520, 455);
            this.pbQ12.Name = "pbQ12";
            this.pbQ12.Size = new System.Drawing.Size(120, 120);
            this.pbQ12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbQ12.TabIndex = 12;
            this.pbQ12.TabStop = false;
            // 
            // pbQ11
            // 
            this.pbQ11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbQ11.Image = global::TextGameFinal.Properties.Resources.undisc;
            this.pbQ11.Location = new System.Drawing.Point(520, 581);
            this.pbQ11.Name = "pbQ11";
            this.pbQ11.Size = new System.Drawing.Size(120, 120);
            this.pbQ11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbQ11.TabIndex = 11;
            this.pbQ11.TabStop = false;
            // 
            // pbQ6
            // 
            this.pbQ6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbQ6.Image = global::TextGameFinal.Properties.Resources.undisc;
            this.pbQ6.Location = new System.Drawing.Point(16, 707);
            this.pbQ6.Name = "pbQ6";
            this.pbQ6.Size = new System.Drawing.Size(120, 120);
            this.pbQ6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbQ6.TabIndex = 10;
            this.pbQ6.TabStop = false;
            // 
            // pbQ8
            // 
            this.pbQ8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbQ8.Image = global::TextGameFinal.Properties.Resources.undisc;
            this.pbQ8.Location = new System.Drawing.Point(268, 707);
            this.pbQ8.Name = "pbQ8";
            this.pbQ8.Size = new System.Drawing.Size(120, 120);
            this.pbQ8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbQ8.TabIndex = 9;
            this.pbQ8.TabStop = false;
            // 
            // pbQ5
            // 
            this.pbQ5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbQ5.Image = global::TextGameFinal.Properties.Resources.undisc;
            this.pbQ5.Location = new System.Drawing.Point(16, 581);
            this.pbQ5.Name = "pbQ5";
            this.pbQ5.Size = new System.Drawing.Size(120, 120);
            this.pbQ5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbQ5.TabIndex = 8;
            this.pbQ5.TabStop = false;
            // 
            // pbQ9
            // 
            this.pbQ9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbQ9.Image = global::TextGameFinal.Properties.Resources.undisc;
            this.pbQ9.Location = new System.Drawing.Point(394, 707);
            this.pbQ9.Name = "pbQ9";
            this.pbQ9.Size = new System.Drawing.Size(120, 120);
            this.pbQ9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbQ9.TabIndex = 7;
            this.pbQ9.TabStop = false;
            // 
            // pbQ10
            // 
            this.pbQ10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbQ10.Image = global::TextGameFinal.Properties.Resources.undisc;
            this.pbQ10.Location = new System.Drawing.Point(520, 707);
            this.pbQ10.Name = "pbQ10";
            this.pbQ10.Size = new System.Drawing.Size(120, 120);
            this.pbQ10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbQ10.TabIndex = 6;
            this.pbQ10.TabStop = false;
            // 
            // pbQ7
            // 
            this.pbQ7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbQ7.Image = global::TextGameFinal.Properties.Resources.undisc;
            this.pbQ7.Location = new System.Drawing.Point(268, 581);
            this.pbQ7.Name = "pbQ7";
            this.pbQ7.Size = new System.Drawing.Size(120, 120);
            this.pbQ7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbQ7.TabIndex = 5;
            this.pbQ7.TabStop = false;
            // 
            // pbQ4
            // 
            this.pbQ4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbQ4.Image = global::TextGameFinal.Properties.Resources.undisc;
            this.pbQ4.Location = new System.Drawing.Point(142, 581);
            this.pbQ4.Name = "pbQ4";
            this.pbQ4.Size = new System.Drawing.Size(120, 120);
            this.pbQ4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbQ4.TabIndex = 4;
            this.pbQ4.TabStop = false;
            // 
            // pbDecor1
            // 
            this.pbDecor1.Image = global::TextGameFinal.Properties.Resources.horus_behdety_32653_1280;
            this.pbDecor1.Location = new System.Drawing.Point(16, 41);
            this.pbDecor1.Name = "pbDecor1";
            this.pbDecor1.Size = new System.Drawing.Size(624, 228);
            this.pbDecor1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbDecor1.TabIndex = 20;
            this.pbDecor1.TabStop = false;
            // 
            // Pyramid
            // 
            this.AcceptButton = this.btnEnter;
            this.AccessibleDescription = "Text-Adventure Game";
            this.AccessibleName = "Pyramid";
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(65)))), ((int)(((byte)(68)))));
            this.ClientSize = new System.Drawing.Size(1353, 839);
            this.Controls.Add(this.pbQ1);
            this.Controls.Add(this.pbQ2);
            this.Controls.Add(this.pbQ3);
            this.Controls.Add(this.pbBridge);
            this.Controls.Add(this.pbQ15);
            this.Controls.Add(this.pbQ14);
            this.Controls.Add(this.pbQ13);
            this.Controls.Add(this.pbQ12);
            this.Controls.Add(this.pbQ11);
            this.Controls.Add(this.pbQ6);
            this.Controls.Add(this.pbQ8);
            this.Controls.Add(this.pbQ5);
            this.Controls.Add(this.pbQ9);
            this.Controls.Add(this.pbQ10);
            this.Controls.Add(this.pbQ7);
            this.Controls.Add(this.pbQ4);
            this.Controls.Add(this.tbLocation);
            this.Controls.Add(this.tbMessageLog);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.tbCommandLine);
            this.Controls.Add(this.pbDecor1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Pyramid";
            this.ShowIcon = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pyramid";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Pyramid_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBridge)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbQ4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDecor1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbCommandLine;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.TextBox tbMessageLog;
        private System.Windows.Forms.TextBox tbLocation;
        private System.Windows.Forms.PictureBox pbQ4;
        private System.Windows.Forms.PictureBox pbQ7;
        private System.Windows.Forms.PictureBox pbQ10;
        private System.Windows.Forms.PictureBox pbQ9;
        private System.Windows.Forms.PictureBox pbQ5;
        private System.Windows.Forms.PictureBox pbQ8;
        private System.Windows.Forms.PictureBox pbQ6;
        private System.Windows.Forms.PictureBox pbQ11;
        private System.Windows.Forms.PictureBox pbQ12;
        private System.Windows.Forms.PictureBox pbQ13;
        private System.Windows.Forms.PictureBox pbQ14;
        private System.Windows.Forms.PictureBox pbQ15;
        private System.Windows.Forms.PictureBox pbBridge;
        private System.Windows.Forms.PictureBox pbQ3;
        private System.Windows.Forms.PictureBox pbQ2;
        private System.Windows.Forms.PictureBox pbQ1;
        private System.Windows.Forms.PictureBox pbDecor1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem resetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetMessageLogToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetGameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    }
}

