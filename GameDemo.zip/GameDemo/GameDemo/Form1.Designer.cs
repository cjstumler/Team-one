﻿namespace GameDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbLocationName = new System.Windows.Forms.TextBox();
            this.tbOutput = new System.Windows.Forms.TextBox();
            this.tbCommand = new System.Windows.Forms.TextBox();
            this.btnEnter = new System.Windows.Forms.Button();
            this.pbBottomLeft = new System.Windows.Forms.PictureBox();
            this.pbBottomRight = new System.Windows.Forms.PictureBox();
            this.pbTopLeft = new System.Windows.Forms.PictureBox();
            this.pbTopRight = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbBottomLeft)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBottomRight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTopLeft)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTopRight)).BeginInit();
            this.SuspendLayout();
            // 
            // tbLocationName
            // 
            this.tbLocationName.BackColor = System.Drawing.Color.Black;
            this.tbLocationName.Font = new System.Drawing.Font("Papyrus", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbLocationName.ForeColor = System.Drawing.Color.White;
            this.tbLocationName.Location = new System.Drawing.Point(12, 12);
            this.tbLocationName.Name = "tbLocationName";
            this.tbLocationName.ReadOnly = true;
            this.tbLocationName.Size = new System.Drawing.Size(535, 70);
            this.tbLocationName.TabIndex = 0;
            this.tbLocationName.Text = "BottomRight";
            this.tbLocationName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbOutput
            // 
            this.tbOutput.BackColor = System.Drawing.Color.Black;
            this.tbOutput.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOutput.ForeColor = System.Drawing.Color.White;
            this.tbOutput.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tbOutput.Location = new System.Drawing.Point(553, 12);
            this.tbOutput.Multiline = true;
            this.tbOutput.Name = "tbOutput";
            this.tbOutput.ReadOnly = true;
            this.tbOutput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbOutput.Size = new System.Drawing.Size(537, 556);
            this.tbOutput.TabIndex = 1;
            this.tbOutput.Text = "Welcome to the game! This is a demo build. Type \'help\' to see a list of commands." +
    " All commands are in lowercase. Press the Enter key to submit a command.";
            // 
            // tbCommand
            // 
            this.tbCommand.BackColor = System.Drawing.Color.Black;
            this.tbCommand.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbCommand.ForeColor = System.Drawing.Color.White;
            this.tbCommand.Location = new System.Drawing.Point(553, 583);
            this.tbCommand.Name = "tbCommand";
            this.tbCommand.Size = new System.Drawing.Size(375, 30);
            this.tbCommand.TabIndex = 2;
            // 
            // btnEnter
            // 
            this.btnEnter.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnEnter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEnter.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnEnter.FlatAppearance.BorderSize = 3;
            this.btnEnter.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnEnter.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnEnter.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEnter.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnter.ForeColor = System.Drawing.Color.White;
            this.btnEnter.Location = new System.Drawing.Point(934, 576);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(156, 42);
            this.btnEnter.TabIndex = 3;
            this.btnEnter.Text = "ENTER";
            this.btnEnter.UseVisualStyleBackColor = false;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // pbBottomLeft
            // 
            this.pbBottomLeft.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbBottomLeft.Image = global::GameDemo.Properties.Resources.newLoc;
            this.pbBottomLeft.Location = new System.Drawing.Point(12, 363);
            this.pbBottomLeft.Name = "pbBottomLeft";
            this.pbBottomLeft.Size = new System.Drawing.Size(255, 250);
            this.pbBottomLeft.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbBottomLeft.TabIndex = 4;
            this.pbBottomLeft.TabStop = false;
            // 
            // pbBottomRight
            // 
            this.pbBottomRight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbBottomRight.Image = global::GameDemo.Properties.Resources.halfLocTHERE;
            this.pbBottomRight.Location = new System.Drawing.Point(292, 363);
            this.pbBottomRight.Name = "pbBottomRight";
            this.pbBottomRight.Size = new System.Drawing.Size(255, 250);
            this.pbBottomRight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbBottomRight.TabIndex = 5;
            this.pbBottomRight.TabStop = false;
            // 
            // pbTopLeft
            // 
            this.pbTopLeft.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbTopLeft.Image = global::GameDemo.Properties.Resources.newLoc;
            this.pbTopLeft.Location = new System.Drawing.Point(12, 88);
            this.pbTopLeft.Name = "pbTopLeft";
            this.pbTopLeft.Size = new System.Drawing.Size(255, 250);
            this.pbTopLeft.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbTopLeft.TabIndex = 6;
            this.pbTopLeft.TabStop = false;
            // 
            // pbTopRight
            // 
            this.pbTopRight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbTopRight.Image = global::GameDemo.Properties.Resources.newLoc;
            this.pbTopRight.Location = new System.Drawing.Point(292, 88);
            this.pbTopRight.Name = "pbTopRight";
            this.pbTopRight.Size = new System.Drawing.Size(255, 250);
            this.pbTopRight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbTopRight.TabIndex = 7;
            this.pbTopRight.TabStop = false;
            // 
            // Form1
            // 
            this.AcceptButton = this.btnEnter;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(1102, 628);
            this.Controls.Add(this.pbTopRight);
            this.Controls.Add(this.pbTopLeft);
            this.Controls.Add(this.pbBottomRight);
            this.Controls.Add(this.pbBottomLeft);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.tbCommand);
            this.Controls.Add(this.tbOutput);
            this.Controls.Add(this.tbLocationName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1120, 675);
            this.MinimumSize = new System.Drawing.Size(1120, 675);
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Text Adventure";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbBottomLeft)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBottomRight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTopLeft)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTopRight)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbLocationName;
        private System.Windows.Forms.TextBox tbOutput;
        private System.Windows.Forms.TextBox tbCommand;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.PictureBox pbBottomLeft;
        private System.Windows.Forms.PictureBox pbBottomRight;
        private System.Windows.Forms.PictureBox pbTopLeft;
        private System.Windows.Forms.PictureBox pbTopRight;
    }
}

