﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameDemo
{
    public partial class Form1 : Form
    {
        string loc = "BottomRight";

        bool BRcomplete = false;
        bool BLcomplete = false;
        bool TRcomplete = false;
        bool TLcomplete = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ActiveControl = tbCommand;
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            //These commands handle movement.

            //NORTH BLOCK
            if (tbCommand.Text == "n" || tbCommand.Text == "north" || tbCommand.Text == "up")
            {
                if (loc == "BottomRight")
                {
                    if (BRcomplete == false && TRcomplete == false)
                    {
                        /*
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go North. You are now in TopRight.");
                        pbBottomRight.Image = Properties.Resources.halfLoc;
                        pbTopRight.Image = Properties.Resources.halfLocTHERE;
                        tbCommand.Text = "";
                        loc = "TopRight";
                        tbLocationName.Text = loc;
                        */

                        move("North", 
                            pbBottomRight, 
                            pbTopRight, 
                            Properties.Resources.halfLoc, 
                            Properties.Resources.halfLocTHERE, 
                            "TopRight");
                    }
                    else if (BRcomplete == true && TRcomplete == false)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go North. You are now in TopRight.");
                        pbBottomRight.Image = Properties.Resources.doneLoc;
                        pbTopRight.Image = Properties.Resources.halfLocTHERE;
                        tbCommand.Text = "";
                        loc = "TopRight";
                        tbLocationName.Text = loc;
                    }
                    else if (BRcomplete == false && TRcomplete == true)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go North. You are now in TopRight.");
                        pbBottomRight.Image = Properties.Resources.halfLoc;
                        pbTopRight.Image = Properties.Resources.doneLocTHERE;
                        tbCommand.Text = "";
                        loc = "TopRight";
                        tbLocationName.Text = loc;
                    }
                    else if (BRcomplete = true && TRcomplete == true)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go North. You are now in TopRight.");
                        pbBottomRight.Image = Properties.Resources.doneLoc;
                        pbTopRight.Image = Properties.Resources.doneLocTHERE;
                        tbCommand.Text = "";
                        loc = "TopRight";
                        tbLocationName.Text = loc;
                    }
                }
                else if (loc == "TopRight")
                {
                    tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You cannot go North from here. Please choose another action.");
                    tbCommand.Text = "";
                }
                else if (loc == "BottomLeft")
                {
                    if (BLcomplete == false && TLcomplete == false)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go North. You are now in TopLeft.");
                        pbBottomLeft.Image = Properties.Resources.halfLoc;
                        pbTopLeft.Image = Properties.Resources.halfLocTHERE;
                        tbCommand.Text = "";
                        loc = "TopLeft";
                        tbLocationName.Text = loc;
                    }
                    else if (BLcomplete == true && TLcomplete == false)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go North. You are now in TopLeft.");
                        pbBottomLeft.Image = Properties.Resources.doneLoc;
                        pbTopLeft.Image = Properties.Resources.halfLocTHERE;
                        tbCommand.Text = "";
                        loc = "TopLeft";
                        tbLocationName.Text = loc;
                    }
                    else if (BLcomplete == false && TLcomplete == true)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go North. You are now in TopLeft.");
                        pbBottomLeft.Image = Properties.Resources.halfLoc;
                        pbTopLeft.Image = Properties.Resources.doneLocTHERE;
                        tbCommand.Text = "";
                        loc = "TopLeft";
                        tbLocationName.Text = loc;
                    }
                    else if (BLcomplete = true && TLcomplete == true)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go North. You are now in TopLeft.");
                        pbBottomLeft.Image = Properties.Resources.doneLoc;
                        pbTopLeft.Image = Properties.Resources.doneLocTHERE;
                        tbCommand.Text = "";
                        loc = "TopLeft";
                        tbLocationName.Text = loc;
                    }
                }
                else if (loc == "TopLeft")
                {
                    tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You cannot go North from here. Please choose another action.");
                    tbCommand.Text = "";
                }
            }

            //SOUTH BLOCK
            else if (tbCommand.Text == "s" || tbCommand.Text == "south" || tbCommand.Text == "down")
            {
                if (loc == "BottomRight")
                {
                    /*
                    tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You cannot go South from here. Please choose another action.");
                    tbCommand.Text = "";
                    */

                    notMove("South");
                }
                else if (loc == "TopRight")
                {
                    if (TRcomplete == false && BRcomplete == false)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go South. You are now in BottomRight.");
                        pbTopRight.Image = Properties.Resources.halfLoc;
                        pbBottomRight.Image = Properties.Resources.halfLocTHERE;
                        tbCommand.Text = "";
                        loc = "BottomRight";
                        tbLocationName.Text = loc;
                    }
                    else if (TRcomplete == true && BRcomplete == false)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go South. You are now in BottomRight.");
                        pbTopRight.Image = Properties.Resources.doneLoc;
                        pbBottomRight.Image = Properties.Resources.halfLocTHERE;
                        tbCommand.Text = "";
                        loc = "BottomRight";
                        tbLocationName.Text = loc;
                    }
                    else if (TRcomplete == false && BRcomplete == true)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go South. You are now in BottomRight.");
                        pbTopRight.Image = Properties.Resources.halfLoc;
                        pbBottomRight.Image = Properties.Resources.doneLocTHERE;
                        tbCommand.Text = "";
                        loc = "BottomRight";
                        tbLocationName.Text = loc;
                    }
                    else if (TRcomplete = true && BRcomplete == true)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go South. You are now in BottomRight.");
                        pbTopRight.Image = Properties.Resources.doneLoc;
                        pbBottomRight.Image = Properties.Resources.doneLocTHERE;
                        tbCommand.Text = "";
                        loc = "BottomRight";
                        tbLocationName.Text = loc;
                    }
                }
                else if (loc == "BottomLeft")
                {
                    tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You cannot go South from here. Please choose another action.");
                    tbCommand.Text = "";
                }
                else if (loc == "TopLeft")
                {
                    if (TLcomplete == false && BLcomplete == false)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go South. You are now in BottomLeft.");
                        pbTopLeft.Image = Properties.Resources.halfLoc;
                        pbBottomLeft.Image = Properties.Resources.halfLocTHERE;
                        tbCommand.Text = "";
                        loc = "BottomLeft";
                        tbLocationName.Text = loc;
                    }
                    else if (TLcomplete == true && BLcomplete == false)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go South. You are now in BottomLeft.");
                        pbTopLeft.Image = Properties.Resources.doneLoc;
                        pbBottomLeft.Image = Properties.Resources.halfLocTHERE;
                        tbCommand.Text = "";
                        loc = "BottomLeft";
                        tbLocationName.Text = loc;
                    }
                    else if (TLcomplete == false && BLcomplete == true)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go South. You are now in BottomLeft.");
                        pbTopLeft.Image = Properties.Resources.halfLoc;
                        pbBottomLeft.Image = Properties.Resources.doneLocTHERE;
                        tbCommand.Text = "";
                        loc = "BottomLeft";
                        tbLocationName.Text = loc;
                    }
                    else if (TLcomplete = true && BLcomplete == true)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go South. You are now in BottomLeft.");
                        pbTopLeft.Image = Properties.Resources.doneLoc;
                        pbBottomLeft.Image = Properties.Resources.doneLocTHERE;
                        tbCommand.Text = "";
                        loc = "BottomLeft";
                        tbLocationName.Text = loc;
                    }
                }
            }

            //EAST BLOCK
            else if (tbCommand.Text == "e" || tbCommand.Text == "east" || tbCommand.Text == "right")
            {
                if (loc == "BottomRight")
                {
                    tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You cannot go East from here. Please choose another action.");
                    tbCommand.Text = "";
                }
                else if (loc == "TopRight")
                {
                    tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You cannot go East from here. Please choose another action.");
                    tbCommand.Text = "";
                }
                else if (loc == "BottomLeft")
                {
                    if (BLcomplete == false && BRcomplete == false)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go East. You are now in BottomRight.");
                        pbBottomLeft.Image = Properties.Resources.halfLoc;
                        pbBottomRight.Image = Properties.Resources.halfLocTHERE;
                        tbCommand.Text = "";
                        loc = "BottomRight";
                        tbLocationName.Text = loc;
                    }
                    else if (BLcomplete == true && BRcomplete == false)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go East. You are now in BottomRight.");
                        pbBottomLeft.Image = Properties.Resources.doneLoc;
                        pbBottomRight.Image = Properties.Resources.halfLocTHERE;
                        tbCommand.Text = "";
                        loc = "BottomRight";
                        tbLocationName.Text = loc;
                    }
                    else if (BLcomplete == false && BRcomplete == true)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go East. You are now in BottomRight.");
                        pbBottomLeft.Image = Properties.Resources.halfLoc;
                        pbBottomRight.Image = Properties.Resources.doneLocTHERE;
                        tbCommand.Text = "";
                        loc = "BottomRight";
                        tbLocationName.Text = loc;
                    }
                    else if (BLcomplete = true && BRcomplete == true)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go East. You are now in BottomRight.");
                        pbBottomLeft.Image = Properties.Resources.doneLoc;
                        pbBottomRight.Image = Properties.Resources.doneLocTHERE;
                        tbCommand.Text = "";
                        loc = "BottomRight";
                        tbLocationName.Text = loc;
                    }
                }
                else if (loc == "TopLeft")
                {
                    if (TLcomplete == false && TRcomplete == false)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go East. You are now in TopRight.");
                        pbTopLeft.Image = Properties.Resources.halfLoc;
                        pbTopRight.Image = Properties.Resources.halfLocTHERE;
                        tbCommand.Text = "";
                        loc = "TopRight";
                        tbLocationName.Text = loc;
                    }
                    else if (TLcomplete == true && TRcomplete == false)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go East. You are now in TopRight.");
                        pbTopLeft.Image = Properties.Resources.doneLoc;
                        pbTopRight.Image = Properties.Resources.halfLocTHERE;
                        tbCommand.Text = "";
                        loc = "TopRight";
                        tbLocationName.Text = loc;
                    }
                    else if (TLcomplete == false && TRcomplete == true)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go East. You are now in TopRight.");
                        pbTopLeft.Image = Properties.Resources.halfLoc;
                        pbTopRight.Image = Properties.Resources.doneLocTHERE;
                        tbCommand.Text = "";
                        loc = "TopRight";
                        tbLocationName.Text = loc;
                    }
                    else if (TLcomplete = true && TRcomplete == true)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go East. You are now in TopRight.");
                        pbTopLeft.Image = Properties.Resources.doneLoc;
                        pbTopRight.Image = Properties.Resources.doneLocTHERE;
                        tbCommand.Text = "";
                        loc = "TopRight";
                        tbLocationName.Text = loc;
                    }
                }
            }

            //WEST BLOCK
            else if (tbCommand.Text == "w" || tbCommand.Text == "west" || tbCommand.Text == "left")
            {
                if (loc == "BottomRight")
                {
                    if (BRcomplete == false && BLcomplete == false)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go West. You are now in BottomLeft.");
                        pbBottomRight.Image = Properties.Resources.halfLoc;
                        pbBottomLeft.Image = Properties.Resources.halfLocTHERE;
                        tbCommand.Text = "";
                        loc = "BottomLeft";
                        tbLocationName.Text = loc;
                    }
                    else if (BRcomplete == true && BLcomplete == false)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go West. You are now in BottomLeft.");
                        pbBottomRight.Image = Properties.Resources.doneLoc;
                        pbBottomLeft.Image = Properties.Resources.halfLocTHERE;
                        tbCommand.Text = "";
                        loc = "BottomLeft";
                        tbLocationName.Text = loc;
                    }
                    else if (BRcomplete == false && BLcomplete == true)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go West. You are now in BottomLeft.");
                        pbBottomRight.Image = Properties.Resources.halfLoc;
                        pbBottomLeft.Image = Properties.Resources.doneLocTHERE;
                        tbCommand.Text = "";
                        loc = "BottomLeft";
                        tbLocationName.Text = loc;
                    }
                    else if (BRcomplete = true && BLcomplete == true)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go West. You are now in BottomLeft.");
                        pbBottomRight.Image = Properties.Resources.doneLoc;
                        pbBottomLeft.Image = Properties.Resources.doneLocTHERE;
                        tbCommand.Text = "";
                        loc = "BottomLeft";
                        tbLocationName.Text = loc;
                    }
                }
                else if (loc == "TopRight")
                {
                    if (TRcomplete == false && TLcomplete == false)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go West. You are now in TopLeft.");
                        pbTopRight.Image = Properties.Resources.halfLoc;
                        pbTopLeft.Image = Properties.Resources.halfLocTHERE;
                        tbCommand.Text = "";
                        loc = "TopLeft";
                        tbLocationName.Text = loc;
                    }
                    else if (TRcomplete == true && TLcomplete == false)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go West. You are now in TopLeft.");
                        pbTopRight.Image = Properties.Resources.doneLoc;
                        pbTopLeft.Image = Properties.Resources.halfLocTHERE;
                        tbCommand.Text = "";
                        loc = "TopLeft";
                        tbLocationName.Text = loc;
                    }
                    else if (TRcomplete == false && TLcomplete == true)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go West. You are now in TopLeft.");
                        pbTopRight.Image = Properties.Resources.halfLoc;
                        pbTopLeft.Image = Properties.Resources.doneLocTHERE;
                        tbCommand.Text = "";
                        loc = "TopLeft";
                        tbLocationName.Text = loc;
                    }
                    else if (TRcomplete = true && TLcomplete == true)
                    {
                        tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You decide to go West. You are now in TopLeft.");
                        pbTopRight.Image = Properties.Resources.doneLoc;
                        pbTopLeft.Image = Properties.Resources.doneLocTHERE;
                        tbCommand.Text = "";
                        loc = "TopLeft";
                        tbLocationName.Text = loc;
                    }
                }
                else if (loc == "BottomLeft")
                {
                    tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You cannot go West from here. Please choose another action.");
                    tbCommand.Text = "";
                }
                else if (loc == "TopLeft")
                {
                    tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " + tbCommand.Text + "\r\n"
                        + "You cannot go West from here. Please choose another action.");
                    tbCommand.Text = "";
                }

            //hi
            }
            else if (tbCommand.Text == "hi")
            {
                tbOutput.AppendText("\r\n" + "\r\n"
                    + "You typed: " + tbCommand.Text + "\r\n" + "Hello!");
                tbCommand.Text = "";
            }

            //check to see if finished
            else if (tbCommand.Text == "done")
            {
                if (TRcomplete == true &&
                    TLcomplete == true &&
                    BRcomplete == true &&
                    BLcomplete == true)
                {
                    MessageBox.Show("You're Done!");
                    tbCommand.Text = "";
                }
                else
                {
                    MessageBox.Show("You're not done...");
                    tbCommand.Text = "";
                }
            }

            //This will be the test "area complete" command.
            else if (tbCommand.Text == "complete")
            {
                if (loc == "BottomRight")
                {
                    BRcomplete = true;
                    pbBottomRight.Image = Properties.Resources.doneLocTHERE;
                    tbCommand.Text = "";
                }
                else if (loc == "TopRight")
                {
                    TRcomplete = true;
                    pbTopRight.Image = Properties.Resources.doneLocTHERE;
                    tbCommand.Text = "";
                }
                else if (loc == "BottomLeft")
                {
                    BLcomplete = true;
                    pbBottomLeft.Image = Properties.Resources.doneLocTHERE;
                    tbCommand.Text = "";
                }
                else if (loc == "TopLeft")
                {
                    TLcomplete = true;
                    pbTopLeft.Image = Properties.Resources.doneLocTHERE;
                    tbCommand.Text = "";
                }
            }

            //This is the help command.
            else if (tbCommand.Text == "help")
            {
                tbOutput.AppendText("\r\n" + "\r\n"
                    + "You typed: " + tbCommand.Text + "\r\n"
                    + "Here is a list of accepted commands:"
                    + "\r\n" + "('north' / 'n' / 'up')"
                    + "\r\n" + "('south' / 's' / 'down')"
                    + "\r\n" + "('east' / 'e' / 'right')"
                    + "\r\n" + "('west' / 'w' / 'left')"
                    + "\r\n" + "'hi'"
                    + "\r\n" + "'complete'"
                    + "\r\n" + "'reset'"
                    + "\r\n" + "'end'");
                tbCommand.Text = "";
            }

            //reset command
            else if (tbCommand.Text == "reset")
            {
                loc = "BottomRight";
                tbLocationName.Text = loc;
                tbOutput.Text = "Welcome to the game! This is a demo build. " +
                    "Type 'help' to see a list of commands. " +
                    "All commands are in lowercase. " +
                    "Press the Enter key to submit a command.";
                pbBottomRight.Image = Properties.Resources.halfLocTHERE;
                pbBottomLeft.Image = Properties.Resources.newLoc;
                pbTopRight.Image = Properties.Resources.newLoc;
                pbTopLeft.Image = Properties.Resources.newLoc;
                TRcomplete = false;
                TLcomplete = false;
                BRcomplete = false;
                BLcomplete = false;
                tbCommand.Text = "";
            }

            else if (tbCommand.Text == "end")
            {
                Application.Exit();
            }

            else error();
        }

        //New movement implementation class
        private void move(string direction, PictureBox p1, PictureBox p2, Image i1, Image i2, string location)
        {
            tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " 
                        + tbCommand.Text + "\r\n"
                        + "You decide to go " 
                        + direction + ". " 
                        + "You are now in " 
                        + location + ".");
            p1.Image = i1;
            p2.Image = i2;
            tbCommand.Text = "";
            loc = location;
            tbLocationName.Text = loc;
        }

        //New non-movement class
        private void notMove(string direction)
        {
            tbOutput.AppendText("\r\n" + "\r\n"
                        + "You typed: " 
                        + tbCommand.Text + "\r\n"
                        + "You cannot go " 
                        + direction 
                        + " from here. Please choose another action.");
            tbCommand.Text = "";
        }

        //Error handler
        private void error()
        {
            tbOutput.AppendText("\r\n" + "\r\n" +
                "There was an error. " +
                "Check to make sure a valid command was entered. " +
                "You can type 'help' for a list of suggested commands.");
            tbCommand.Text = "";
        }
    }
}